const MyButton = ({ to }) => { 

	return ( 
		<a href={`/${to}`}> 
			<button className="my-button"> 
				Take me to {to === '' ? "login" : to} 
			</button> 
		</a> 
	) 
} 

export default MyButton;
