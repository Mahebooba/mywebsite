import React, { useState } from 'react';
import { Link } from 'react-router-dom';
const Login = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    if (username === 'IBlog' && password === 'Iblog@123') {
      onLogin(true);
    } else {
      setError('Invalid username or password');
    } 
  };
  return (
    <div className="login">
        <div class="fields">
            <h1>Login Page</h1>
            <br/>
            {error && <p className="error">{error}</p>}
            <form onSubmit={handleLogin}>
                <div className="form-group">
                    <label>Username:</label>
                    <input className='ncolor' type="text" value={username} onChange={(e) => setUsername(e.target.value)} required />
                </div>
                <div className="form-groups">
                        <label>Password:</label>
                        <input className='pcolor' type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div><br></br><br/>
                <Link to="/home">
                        <button className='bcolor' type="submit">Login</button>
                </Link>
            </form>
                        
        </div>
    </div>
   );
};
export default Login;