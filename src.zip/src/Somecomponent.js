import React from 'react';
import { useNavigate } from 'react-router-dom';

function SomeComponent() {
  const history = useNavigate();

  const handleClick = () => {
    history.push('/login');
  };

  return (
    <button onClick={handleClick}>
      Go to About Page
    </button>
  );
}

export default SomeComponent;