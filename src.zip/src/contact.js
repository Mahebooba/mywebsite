import React from "react";
import './contact.css';
import { Link } from "react-router-dom";
function Contact()
{
    return(
        <div>
            <nav class="navigation max-width1 m-auto">
        <div class="nav-left">
            <span>IBlog</span>
            <ul>
                <li><a href="/">Home</a>
                </li>

                <li><a href="#"></a>
                <Link to="/about">About</Link>
                </li>
                <li><a href="/contact"></a>
                <Link to="/contact">Contact</Link>
                </li>
            </ul>
        </div>
        <p class="nav-right">
         <form action="/js/">
            <input class="form-input" type="text" placeholder="Article Search"/>
            <Link to="/search">
            <button class="search">search</button>
            </Link>
          </form>
        </p>
    </nav>
            <div class="contact-content">
                <div class="max-width1 m-auto font1 ">
                    <br/>
                    <h2 font2>Feel free to contact us</h2>
                    <br/>
                    <br/>
                    <div class="form-box">
                        <input type="text" placeholder="Enter your name"/>
                    </div>
                    <div class="form-box">
                            <input type="text" placeholder="Enter your Phone Number"/>
                    </div>
                    <div class="form-box">
                        <input type="text" placeholder="Enter your Email"/>
                    </div>
                    <div class="form-box">
                        <textarea name="" id="" rows="5" cols="20" placeholder="How can i help....."></textarea>
                    </div>
                      <button class="bnt" type="submit">Submit</button>
                    
            </div>
        </div>
        <div class="footer max-width2 m-auto">
          <p>Copyright & copy; IBlog.com</p>
           <a href="https://www.vecteezy.com/">Vecteezy</a>
        </div>
     </div>
    );
}
export default Contact;