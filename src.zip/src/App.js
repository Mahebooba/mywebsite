import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import SignUp from './signup.js';
//import './App.css';
import './login.css';
// import HomeContent from './homecontent.js';
import Home from './home.js';
import Login from './login.js';
import BHome from './bloghome.js';
import HomeContent from './homecontent.js';
import Contact from './contact.js';
import Search from './search.js';
import Group from './group.js';
import Homepage from './loginpage.js';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />}/>
        <Route path="/signup" element={<SignUp />} />
        <Route path="/bloghome" element={<BHome />} />
        <Route path="/about" element={<HomeContent />}/>
        <Route path="/contact" element={<Contact />}/>
        <Route path="/search" element={<Search/>}/>
        <Route path="/group" element={<Group/>}/>
        <Route path="/blog" element={<Group/>}/>
        <Route path="/home" element={<Homepage/>}/>


        
      </Routes>
    </Router>
  );
}

export default App;