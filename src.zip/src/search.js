import React from "react";
import logo from './item.jpg'
import { Link } from "react-router-dom";
function Search()
{
    return(
    <div>
    <nav class="navigation max-width1 m-auto">
        <div class="nav-left">
            <span>IBlog</span>
            <ul>
                <li><a href="/">Home</a>
                </li>

                <li><a href="#"></a>
                <Link to="/about">About</Link>
                </li>
                <li><a href="/contact"></a>
                <Link to="/contact">Contact</Link>
                </li>
            </ul>
        </div>
        <p class="nav-right">
         <form action="/js/">
            <input class="form-input" type="text" placeholder="Article Search"/>
            <Link to="/search">
            <button class="search">search</button>
            </Link>
          </form>
        </p>
    </nav>
        <h2 font2>Results for search</h2>
        <div class="home-article">
            
                <img src={logo} alt="img1"/>
                <Link to="/group">group1:</Link>
                
                <div>
                <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
                </div>
        </div> 
        <div class="home-article">
            
            <img src={logo}alt="img1"/>
            <Link to="/group">group1:</Link>
            
            <div>
            <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
            </div>
         </div> 
        <div class="home-article">
            
        <img src={logo} alt="img1"/>
       <Link to="/group">group1:</Link>
        
            <div>
            <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
            </div>
        </div> 
    </div>
    );
}
export default Search;