import React  from "react";
import {Outlet,Link} from "react-router-dom";
const Form = ()=>{
     return(
        <>
          <nav>
            <ol>
                <li>
                    <Link to="/login">Log In</Link>
                </li>
            </ol>
          </nav>
          <Outlet></Outlet>
        </>
        
     );
}
export default Form;