import React from "react";
import logo from './item.jpg';
import {Link} from 'react-router-dom';
import './group.css';
import './home.css';
function Group(){
    return(
        <div>
            <nav class="navigation max-width1 m-auto">
        <div class="nav-left">
            <span>IBlog</span>
            <ul>
                <li><a href="/">Home</a>
                </li>

                <li><a href="#"></a>
                <Link to="/about">About</Link>
                </li>
                <li><a href="/contact"></a>
                <Link to="/contact">Contact</Link>
                </li>
            </ul>
        </div>
        <p class="nav-right">
         <form action="/js/">
            <input class="form-input" type="text" placeholder="Article Search"/>
            <Link to="/search">
            <button class="search">search</button>
            </Link>
          </form>
        </p>
    </nav>
            <hr class="max-width1 m-auto"/>
    <div class="blog-content max-width1 m-auto">
        <img src={logo} alt="img1"/>
        <div>
            <h2>Blog</h2>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Natus delectus itaque 
                enim quos laudantium tempore dolorem, ratione deserunt dolor consectetur unde 
                dolore earum non qui libero, doloribus doloremque, maxime culpa?Lorem ipsum dolor 
                sit amet consectetur adipisicing elit. Dolorem facilis dolorum, soluta sunt ipsam 
                laborum delectus maxime ad illo rerum aperiam pariatur porro vitae nobis autem natus 
                a. Labore, deserunt.
            </p>
        </div>

    </div>
        <hr class="max-width1 m-auto"/>
    <div class="max-width1 m-auto home-articles">
        <h2 font2>Reffered Articles</h2>
        <div class="max-width1 home-article1">
            <div class="home-article">
                <img src={logo} alt="img1"/>
                <Link to="/group">Blog1:</Link>
                <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
            </div>
            <div class=" home-article">
                <img src={logo} alt="img1"/>
                <Link to="/group">Blog2</Link> 
                <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
            </div>
            <div class= "home-article">
                <img src={logo} alt="img1"/>
                <Link to="/group">Blog3</Link>
                <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
            </div>

        </div>
    </div>
  </div>

    );
}
export default Group;