import React from 'react';
import { Link } from 'react-router-dom';
import './home.css';
import logo from'./bulb.jpg'
import img from './item.jpg'
const Home = () => {
  return (
<div>
    <nav class="navigation max-width1 m-auto">
        <div class="nav-left">
            <span>IBlog</span>
            <ul>
                <li><a href="/">Home</a>
                </li>

                <li><a href="#"></a>
                <Link to="/about">About</Link>
                </li>
                <li><a href="/contact"></a>
                <Link to="/contact">Contact</Link>
                </li>
            </ul>
        </div>
        <p class="nav-right">
         <form action="/js/">
            <input class="form-input" type="text" placeholder="Article Search"/>
            <Link to="/search">
            <button class="search">search</button>
            </Link>
          </form>
        </p>
    </nav>
   
    <div class="content max-width1 m-auto">
        <div class="content-left">
            <h1>The Heaven For Bloggers</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam blanditiis, soluta eos 
                perspiciatis pariatur ex nulla dolorem maxime placeat labore exercitationem
                 iste corrupti facere modi est nisi voluptate suscipit dolorum.</p>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente pariatur voluptatem saepe necessitatibus, natus, quidem at enim explicabo
                reprehenderit cumque eum! Reiciendis odit minima aliquid commodi voluptatem natus voluptate debitis.
            </p>

        </div>
        <div class="content-right">
            <img src={logo} alt="Logo"/>

        </div>
    </div>
    <hr class="max-width1 m-auto"/>
    <div class="max-width1 m-auto home-articles">
        <h2 font2>Featured Articles</h2>
        <div class="home-article">
          <div>
            <img src={img} alt="img1"/>
            <Link to="/blog">Blog1</Link> 
                <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
        </div>
            <div>
              <img src={img} alt="img2"/>
              <Link to="/blog">Blog2</Link> 
                <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
            </div>
            <div>
            <img src={img} alt="img3"/>
            <Link to="/blog">Blog3</Link> 
                <p>Lorem ipsum dolor, sit amet consect dipisicing elit. Eius dolorem mollitia</p>
            </div>

        </div>
    </div>
    <div class="but">
      <Link to="/login">
    <button class="butt" type="submit">Sign In</button>
    </Link>
  </div>
   
  </div>
  
  );
};

export default Home;